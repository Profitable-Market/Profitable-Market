# Profitable Market

Professional broker-style PRACTICE platform using simulated funds.

## Included
- Landing page
- Demo registration and login
- Simulated trading dashboard
- Simulated market quotes and chart
- Buy/sell demo orders
- Open positions
- Demo funding
- Trade history
- Demo admin panel

## How to use
Open `index.html` in a modern web browser, or upload it to a static hosting/deployment service.

Accounts and demo activity are stored locally in the browser for private testing.

## Important
This project is intentionally a simulation. It does not process real money, real deposits, real withdrawals, or real trades, and it is not a licensed brokerage platform.
